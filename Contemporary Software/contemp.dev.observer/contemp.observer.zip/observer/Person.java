
public class Person {
  
  public Person(String a_name){
    name = a_name;
  }
  
  public void goToBed(){
    System.out.println(name + " is going to bed...");
  }
  
  public void wakeUp(){
    System.out.println(name + " has woken up!");
  }
  
  private String name;
}
