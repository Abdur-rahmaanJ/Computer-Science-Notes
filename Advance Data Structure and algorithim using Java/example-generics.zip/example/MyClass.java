package example;

public class MyClass {
	int data;
	String data2;
	
	public int getData() {
		return data;
	}
	
	public void setData(int data) {
		this.data = data;
	}
}
