package example4;

public class MyClass<TheTypeOfDataIAmStoring> {
	TheTypeOfDataIAmStoring data;
	
	public TheTypeOfDataIAmStoring getData() {
		return data;
	}
	
	public void setData(TheTypeOfDataIAmStoring data) {
		this.data = data;
	}
}
