


public class W1Q5 {
	public static void main(String[] args) {
		int i = 20;
		int s = 0;
		
		while (i >= 0) {
			if (i < 20) System.out.print(",");
			
			System.out.print(i);
			i = i - 2;
		}
	}
}
