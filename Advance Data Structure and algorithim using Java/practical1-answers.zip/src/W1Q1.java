

public class W1Q1 {
	public static void main(String[] args) {
		int x = 5;
		int y = 7;
		int s = x + y;
		
		System.out.println(x + " plus " + y + " is " + s);
	}
}
