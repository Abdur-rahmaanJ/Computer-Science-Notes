//week3_2s.c
//lab week3 question 2 model solution
#include <stdio.h>
#include <limits.h>

int main(){
	
	char c;
	printf("%lu\n", sizeof(c));
	short s;
	printf("%lu\n", sizeof(s));
	int i;
	printf("%lu\n", sizeof(i));
	long l;
	printf("%lu\n", sizeof(l));
	float f;
	printf("%lu\n", sizeof(f));
	double d;
	printf("%lu\n", sizeof(d));
	long double ld;
	printf("%lu\n", sizeof(ld));
}
