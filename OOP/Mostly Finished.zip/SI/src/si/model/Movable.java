package si.model;

public interface Movable {
	public void move();
}
