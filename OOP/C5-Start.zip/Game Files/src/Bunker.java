
public class Bunker {
  int x, y;
  Brick[] bricks;

  Bunker(int x1, int y1) {
    x = x1;
    x = y1;
    bricks = new Brick[26];
  }
}
