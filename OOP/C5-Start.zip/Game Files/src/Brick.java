
public class Brick {
  int x, y;
  int width;

  Brick(int x1, int y1, int w) {
    x = x1;
    y = y1;
    width = w;
  }
}
