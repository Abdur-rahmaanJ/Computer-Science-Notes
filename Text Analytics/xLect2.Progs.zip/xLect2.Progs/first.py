'''import nltk
tfile = open('text.txt')
rawtext = tfile.read()
tokens = nltk.word_tokenize(rawtext)
print(tokens)
words = [word.lower() for word in tokens ]
print(words)
'''
