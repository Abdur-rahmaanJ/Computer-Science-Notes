print('welcome to monty')
