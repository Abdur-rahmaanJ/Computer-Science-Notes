library(wordcloud)
library(tm)
wordcloud("May our children and our children's children to a thousand generations, continue to enjoy the benefits conferred upon us by a united country, and have cause yet to rejoice under those glorious institutions bequeathed us by Washington and his compeers.",colors=brewer.pal(6,"Dark2"),random.order=FALSE)