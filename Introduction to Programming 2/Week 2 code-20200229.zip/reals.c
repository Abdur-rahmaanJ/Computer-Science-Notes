#include <float.h>
#include <stdio.h>
int main() {
   printf( "FLT_MIN: %f\n", FLT_MIN );
   printf( "FLT_MAX: %f\n", FLT_MAX );
   printf( "DBL_MIN: %lf\n", DBL_MIN );
   printf( "DBL_MAX: %lf\n", DBL_MAX );
}
