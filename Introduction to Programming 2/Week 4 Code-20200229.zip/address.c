/*file address.c*/
#include <stdio.h>
int main() {
   int a = 6;

   // print value stored in a
   printf( "%d\n", a ); 

   // print the address of a
   printf( "%p\n", &a );
}
