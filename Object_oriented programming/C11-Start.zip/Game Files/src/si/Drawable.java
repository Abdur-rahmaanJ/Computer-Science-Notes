package si;
import java.awt.Rectangle;

public interface Drawable {
  Rectangle[] getShape();
}