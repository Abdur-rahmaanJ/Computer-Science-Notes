package si;
public interface Movable {
  void move();
}