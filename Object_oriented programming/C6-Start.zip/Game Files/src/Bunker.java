
public class Bunker {
  private int x, y;
  private Brick[] bricks;
  public static final int BRICK_SIZE = 5;

  public Bunker(int x1, int y1) {
    x = x1;
    x = y1;
    bricks = new Brick[26];
  }
}
