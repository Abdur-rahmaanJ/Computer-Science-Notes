
class Testasp
	def initialize(a, b, c)
		@a = a
		@b = b
		@c = c
	end
	
	def initialize(x, y)
		@x = x
		@y = y
	end
end

#p Testasp.new(1, 2, 3, 4)
p Testasp.new(1, 2)
