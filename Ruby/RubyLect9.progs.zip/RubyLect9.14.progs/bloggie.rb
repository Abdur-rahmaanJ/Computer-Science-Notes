=begin
Bloggie.please

class Bloggie
	def self.please
	   p "please"
	end
end

#bloggie.rb:2:in `<main>': uninitialized constant Object::Bloggie (NameError)
=end


class Bloggie

	def self.please
	   p "please"
	end
end

Bloggie.please
