class TestController < ApplicationController
  def hello
    @message = "hello"
  end
end
