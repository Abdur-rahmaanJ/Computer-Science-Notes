class FamilyMember
  p 2
end