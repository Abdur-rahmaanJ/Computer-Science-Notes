###########
# ERROR
## Copyright Mark Keane, All Rights Reserved, 2013

def my_error(sp_message)
	puts "\n**ERROR** Problem with #{sp_message}.\n" 
end
