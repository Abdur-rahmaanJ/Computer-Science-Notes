###########
# THANKS
## Copyright Mark Keane, All Rights Reserved, 2013

def print_thanks
	puts "Thanks for that."
end
