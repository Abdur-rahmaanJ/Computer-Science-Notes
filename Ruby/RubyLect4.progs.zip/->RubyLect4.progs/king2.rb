##############
# UPDATED FOR CATEGORIES
## Copyright Mark Keane, All Rights Reserved, 2011


x = "mark"

def hail_the_king(name)
	puts "hail king " + name
end 

hail_the_king(x)
