
def hail_mark
	puts "hail mark"
end

hail_mark