# Copyright Mark Keane, All Rights Reserved, 2016

def hail_the_king
	puts "hail king mark"
end

print $LOAD_PATH

hail_the_king