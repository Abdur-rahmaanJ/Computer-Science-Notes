# Copyright Mark Keane, All Rights Reserved, 2016

def test
	puts "hi there big boy !"
end

#print $LOAD_PATH

test