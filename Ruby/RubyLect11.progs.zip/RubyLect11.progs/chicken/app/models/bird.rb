class Bird < ActiveRecord::Base
end
