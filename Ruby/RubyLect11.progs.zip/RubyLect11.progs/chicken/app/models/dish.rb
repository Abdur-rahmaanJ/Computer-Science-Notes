class Dish < ActiveRecord::Base
end
