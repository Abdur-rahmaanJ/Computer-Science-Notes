# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Chicken::Application.config.secret_key_base = '3fe4652edcd2b9792861ded28ad10c87b100329cfe32b06621d837921caeaf7282ba6685b68a30e62dd4d6b1237eec78097777e92af6d6334185455837e0b130'
