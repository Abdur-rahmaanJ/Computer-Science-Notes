class Actor < ActiveRecord::Base
  has_many :songs
end
