class Song < ActiveRecord::Base
   	belongs_to :actor
end
