module GoodbyeHelper
end
