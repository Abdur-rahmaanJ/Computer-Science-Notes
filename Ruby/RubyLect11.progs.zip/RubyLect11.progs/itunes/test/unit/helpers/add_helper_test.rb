require 'test_helper'

class AddHelperTest < ActionView::TestCase
end
