require 'test_helper'

class GoodbyeHelperTest < ActionView::TestCase
end
