require 'test_helper'

class BuyHelperTest < ActionView::TestCase
end
