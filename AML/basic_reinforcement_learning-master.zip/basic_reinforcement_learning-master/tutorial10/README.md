# Guided Policy Search gradients (GPS)

Refer to the [corresponding notebook](gps_notebook.ipynb).

 ### Resources:
