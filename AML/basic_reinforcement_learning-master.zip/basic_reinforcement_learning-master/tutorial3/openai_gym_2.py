from gym import envs
print len(envs.registry.all())