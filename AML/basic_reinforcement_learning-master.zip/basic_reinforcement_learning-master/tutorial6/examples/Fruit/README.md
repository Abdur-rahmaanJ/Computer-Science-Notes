# Fruit
Toy example of a deep reinforcement learning model playing a game of catching fruit.
<img src="files/fruit.gif" />
