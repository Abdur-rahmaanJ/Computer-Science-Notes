# Trying out `readme2tex`

Hello, this is a trial of an equation $x = a_1 + b_2$.

$$
\frac{n!}{k!(n-k)!} = {n \choose k}
$$
