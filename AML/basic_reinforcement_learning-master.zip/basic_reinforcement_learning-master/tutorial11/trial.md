# Trying out `readme2tex`

Hello, this is a trial of an equation <img src="https://rawgit.com/vmayoral/basic_reinforcement_learning/master//tutorial11/tex/0c2f6d0706c33529be716451d97de164.svg?invert_in_darkmode" align=middle width=81.074895pt height=22.831379999999992pt/>.

<p align="center"><img src="https://rawgit.com/vmayoral/basic_reinforcement_learning/master//tutorial11/tex/32737e0a8d5a4cf32ba3ab1b74902ab7.svg?invert_in_darkmode" align=middle width=127.984725pt height=39.45249pt/></p>
