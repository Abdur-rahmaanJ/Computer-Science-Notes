# Benchmarking RL techniques

Benchmarks performed in `MountainCarContinuous-v0`:

![](imgs/mountain.png)

Benchmarks performed in `Pendulum-v0`:

![](imgs/pendulum.png)

Code available [here](code/).
