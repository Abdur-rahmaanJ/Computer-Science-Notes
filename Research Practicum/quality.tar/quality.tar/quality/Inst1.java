import javassist.*;
 
public class Inst1 {
    public static void main(String[] args) throws Exception {
        ClassPool pool = ClassPool.getDefault();
        CtClass hw_ctc = pool.get("HelloWorld");
        CtMethod hw_ctm = hw_ctc.getDeclaredMethod("do1");
        hw_ctm.insertBefore("System.out.println(\"HelloWorld.do1() Start\");");
        hw_ctm.insertAfter("System.out.println(\"HelloWorld.do1() End\");");
        CtMethod hw_ctm2 = hw_ctc.getDeclaredMethod("do2");
	hw_ctm2.insertBefore("System.out.println(\"HelloWorld.do2() Start\");");
	Class hw_class = hw_ctc.toClass();
        HelloWorld hw = (HelloWorld)hw_class.newInstance();
        hw.do1();
        hw.do2("Goodbye world");
    }
}
