public class HelloWorld {
    public void do1() {
        System.out.println("Hello World!");
    }
 
    public void do2(String tosay){
        System.out.println(tosay);
    }
 
}
