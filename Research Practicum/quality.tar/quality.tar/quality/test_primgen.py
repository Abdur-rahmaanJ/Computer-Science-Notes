from prime import PrimeGenerator

def test_first_primes():
    pg = PrimeGenerator()
    assert pg.first_primes(6) == [2, 3, 5, 7, 11, 13]
