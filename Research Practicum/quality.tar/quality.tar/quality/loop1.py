N=5000
M=100


def function():
        a =[[1 for x in range(M)] for x in range(N)]
        for k in range (0,M):
		for j in range (0,M):
			for i in range (0,N):
				a[i][j] = 2* a[i][j]
	return a

def function2():
	a =[[1 for x in range(N)] for x in range(N)]
        b =[[1 for x in range(N)] for x in range(N)]
        c =[[1 for x in range(N)] for x in range(N)]
        d =[[1 for x in range(N)] for x in range(N)]

        for i in range (0,N):
                for j in range (0,N):
			a[i][j] = 1/b[i][j] * c[i][j];
	for i in range (0,N):
                for j in range (0,N):
			d[i][j] = a[i][j] + c[i][j];

def main():
	function()

if __name__ == "__main__":
	main() 
