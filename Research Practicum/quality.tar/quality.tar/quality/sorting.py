import random
import time

@profile
def bubble_sort(items):
    """ Implementation of bubble sort """
    for i in range(len(items)):
        for j in range(len(items)-1-i):
            if items[j] > items[j+1]:
                items[j], items[j+1] = items[j+1], items[j]

@profile
def init_quick_sort(items):
    quick_sort(items)

def quick_sort(items):
    """ Implementation of quick sort """
    if len(items) > 1:
        pivot_index = len(items) / 2
        smaller_items = []
        larger_items = []

        for i, val in enumerate(items):
            if i != pivot_index:
                if val < items[pivot_index]:
                    smaller_items.append(val)
                else:
                    larger_items.append(val)

        quick_sort(smaller_items)
        quick_sort(larger_items)
        items[:] = smaller_items + [items[pivot_index]] + larger_items


def main():
	random_items = [random.randint(0, 10000) for c in range(5000)]
	bubble_sort(random_items)
	
	random_items = [random.randint(0, 10000) for c in range(50000)]
	init_quick_sort(random_items)


if __name__ == '__main__':
    main()
