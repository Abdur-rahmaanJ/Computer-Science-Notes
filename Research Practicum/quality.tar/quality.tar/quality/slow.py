from time import sleep
 
@profile
def slow(x):
	sleep(2)
	return x
 
@profile
def function(x):
	a = []
	for i in range(x):
		a.append(i)
	b = slow(a)
	del b
	del a
 
print function(100000)

