import javassist.*;
 
public class Inst2 {
    public static void main(String[] args) throws Exception {
        ClassPool pool = ClassPool.getDefault();
        CtClass hw_ctc = pool.get("HelloWorld");
        CtMethod[] hw_ctms = hw_ctc.getDeclaredMethods();
        for(int i=0; i<hw_ctms.length;i++){
            hw_ctms[i].insertBefore("System.out.println(\"HelloWorld." + hw_ctms[i].getName() + " Start\");");
            hw_ctms[i].insertAfter("System.out.println(\"HelloWorld." + hw_ctms[i].getName() +" End\");");
        }
        Class hw_class = hw_ctc.toClass();
        HelloWorld hw = (HelloWorld)hw_class.newInstance();
        hw.do1();
        hw.do2("Goodbye world");
    }
}
