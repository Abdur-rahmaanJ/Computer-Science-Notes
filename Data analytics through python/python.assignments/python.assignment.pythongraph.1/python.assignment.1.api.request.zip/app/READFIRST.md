
# Instructions
- have python 3 / mac 
- run comand in terminal : sh python_assignment.sh if you want to restart the whole process
- OR -> 
- cd to app and run : jupyter notebook 

# IMPORTANT NOTE : due to subscription issues, if you run into issues with the api use the main json

# WHAT SCRIPT DOES : 
	Steps to set up venv:
	- cd into the directory
	- run: mkdir venv
	- go into the directory with: cd venv2
	- then run: python3 -m venv .
	- go back to main directory: cd ../
	- start the venv: source venv/bin/activate
	- install requirements by running: pip install -r requirements.txt
	- to run the notebook: jupyter notebook
	- this will open the browser. to go: http://localhost:8888/tree

>>>>>>>>>>>>>>

SERVER SIDE: 
	- start the venv for python3 by running: source venv/bin/activate
	- then run to install the python requirements : pip install -r requirements.txt 
	- finally run to execute the script : python get_api_data.py 

- To start the server, run : 
	- python -m http.server
	- then go to http://0.0.0.0:8000/web/ to see the chart

>>>>>>>>>>>>>>

NOTE: 
To get the API key, sign up on https://home.openweathermap.org/users/sign_up
and you can see your default API key in your account.

You can execute the python script either through the command line or the python3
option on the browser. 

To run the python file that gets data from the API and saves in JSON file, run :

<!-- 
import get_api_data
get_api_data.getWeatherData() 
-->
