# Import Requests and json modules
import requests
import json

def getWeatherData():
    # openweathermap API key and URL
    API_KEY = "015875585e5ac83b793835e137d645f7"
    # other api = 89c75b9c163463f8c4df5decb0dae468
    API_URL = "https://api.openweathermap.org/data/2.5/forecast/daily?q="


    # Number of days to fetch data for
    days_count = 16
    # The city and country code to get data for
    city_name = "Berlin"
    country_code = "de"

    # the request URL with all the values in place
    # request_url = API_URL + city_name + "," + country_code + "&appid=" + API_KEY
    request_url = API_URL + city_name + "," + country_code + "&cnt=" + str(days_count) + "&appid=" + API_KEY
    print(request_url)
    # Making the request. This returns a JSON data from the API
    res = requests.get(request_url)
    weather_data = json.loads(res.text)

    # Write the JSON data returned from API to weather_data.json file
    with open('./data/weather_data.json', 'w') as outfile:
        json.dump(weather_data, outfile)

    # print(weather_data) # this would get you the weaher data url
    print('**** Data saved! ****')
