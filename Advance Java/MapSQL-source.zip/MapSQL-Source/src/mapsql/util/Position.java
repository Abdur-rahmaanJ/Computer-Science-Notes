package mapsql.util;

public interface Position<T> {
	public T element();
}
