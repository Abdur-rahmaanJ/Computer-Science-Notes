package mapsql.util;

public class RankOutOfBoundsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1086754230766117073L;

}
