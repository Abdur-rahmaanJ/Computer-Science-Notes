package message;

import service.core.Quotation;

public class Quote {
	public Quotation quotation;
	
	public Quote(Quotation quotation) { this.quotation = quotation; }
}
