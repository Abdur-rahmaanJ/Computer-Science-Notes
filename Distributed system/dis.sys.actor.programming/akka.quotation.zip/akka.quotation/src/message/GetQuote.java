package message;

import service.core.ClientInfo;

public class GetQuote {
	public GetQuote(ClientInfo info) { this.info = info; }
	public ClientInfo info;
}
