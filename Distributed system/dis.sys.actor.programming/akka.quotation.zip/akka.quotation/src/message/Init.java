package message;

public class Init {
	public int replies;
	
	public Init(int replies) {
		this.replies = replies;
	}
}
