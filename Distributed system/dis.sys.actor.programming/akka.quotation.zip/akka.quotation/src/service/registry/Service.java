package service.registry;

public interface Service {

}
