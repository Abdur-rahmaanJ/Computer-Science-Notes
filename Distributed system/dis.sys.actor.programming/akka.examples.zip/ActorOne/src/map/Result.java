package map;

public class Result {
	public Result(int value) {
		this.value = value;
	}
	
	public int value;
}
