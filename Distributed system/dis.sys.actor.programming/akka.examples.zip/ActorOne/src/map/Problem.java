package map;

public class Problem {
	public int[] list;
	public int start;
	public int end;

	public Problem(int[] list, int start, int end) {
		this.list = list;
		this.start = start;
		this.end = end;
	}
}
