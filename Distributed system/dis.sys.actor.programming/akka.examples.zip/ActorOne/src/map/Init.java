package map;

public class Init {
	public int numbers;
	public int workers;
	
	public Init(int numbers, int workers) {
		this.numbers = numbers;
		this.workers = workers;
	}

}
