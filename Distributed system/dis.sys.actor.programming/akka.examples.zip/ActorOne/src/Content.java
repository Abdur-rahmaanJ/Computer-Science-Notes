
public class Content {
	private String message;
	
	public Content(String message) {
		this.message = message;
	}

	public String message() {
		return message;
	}
}
